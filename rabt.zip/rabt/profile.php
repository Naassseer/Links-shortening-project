<!DOCTYPE html>
<html>
  <head>
    <title>ربط - حسابي</title>
    <link rel="icon" type="image/png" href="./assets/img/favicon.png" />
    <link rel="stylesheet" href="./assets/css/style.css" />
    <link rel="stylesheet" href="./assets/css/sidebar.css" />
    <link rel="stylesheet" href="./assets/css/profile.css" />
  </head>
  <body class="dashboard">
    <?php
      include './assets/php/auth.php';
      if (!$loggedIn) {
        header("location: login.php");
        exit;
      }
      
      $page = "profile";
      include './assets/php/sidebar_header.php';
    ?>
      <h1>حسابي</h1>
      <div class="group">
        <h2>التفضيلات</h2>
        <form action="profile.php" method="post" onsubmit="checkPreference(event, '<?php echo $user['username'] ?>', '<?php echo $user['email'] ?>')">
          <?php
            if (isset($_POST['preference'])) {
              $con = mysqli_connect('localhost', 'root', '', 'rabt');
              mysqli_set_charset($con, 'utf8');
              
              $id = $user['id'];
              $username = trim($_POST['username']);
              $email = trim($_POST['email']);
              $error = false;
              
              if ($username == "") {
                echo '<p class="error">يجب ان لا تترك خانة اسم المستخدم فارغة</p>';
                $error = true;
              }
              
              if ($email == "") {
                echo '<p class="error">يجب ان لا تترك خانة البريد الإلكتروني فارغة</p>';
                $error = true;
              }
              
              if ($username == $user['username'] && $email == $user['email']) {
                echo '<p class="error">لم تعدل على اسم المستخدم والبريد الإلكتروني</p>';
                $error = true;
              }
              
              if (str_contains($username, ' ')) {
                echo '<p class="error">يجب ان لا يحتوي اسم المستخدم على مسافات</p>';
                $error = true;
              }
              
              if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo '<p class="error">يجب ان يكون البريد الإلكتروني المدخل صحيح</p>';
                $error = true;
              }
              
              if ($username != $user['username']) {
                $checkUsername = mysqli_query($con,"select id from users where username = '$username'");
                if (mysqli_num_rows($checkUsername) > 0) {
                  echo '<p class="error">اسم المستخدم غير متاح</p>';
                  $error = true;
                }
              }
              
              if ($email != $user['email']) {
                $checkEmail = mysqli_query($con,"select id from users where email = '$email'");
                if (mysqli_num_rows($checkEmail) > 0) {
                  echo '<p class="error">البريد الإلكتروني غير متاح</p>';
                  $error = true;
                }
              }
             
              
              if (!$error) {
                
                if ($user['username'] != $username  && $user['email'] != $email) {                 
                  $update = "update users set username = '$username', email = '$email' where id = '$id'";
                } elseif ($user['username'] != $username && $user['email'] == $email) {
                  $update = "update users set username = '$username' where id = '$id'";
                } elseif ($user['username'] == $username && $user['email'] != $email) {
                  $update = "update users set email = '$email' where id = '$id'";
                }

                $updateUser = mysqli_query($con, $update);
                if ($updateUser) {
                  $user['username'] = $username;
                  $user['email'] = $email;
                  $_COOKIE['user'] = json_encode($user);
                  setcookie("user", json_encode($user), time() + 60 * 60 * 24 * 7, '/');
                  echo "<p class='success'>تم تعديل التفضيلات بنجاح</p>";
                }
              }
              
              mysqli_close($con);
            }
          ?>
          <label>اسم المستخدم</label>
          <input
            type="text"
            name="username"
            id="username"
            placeholder="ادخل اسم المستخدم"
            value="<?php echo $user['username'] ?>"
            class="input"
          />
          <label>البريد الإلكتروني</label>
          <input
            type="email"
            name="email"
            id="email"
            placeholder="ادخل البريد الإلكتروني"
            value="<?php echo $user['email'] ?>"
            class="input"
          />
          <input type="submit" name="preference" class="btn" value="تعديل التفضيلات" />
        </form>
      </div>
      <div class="group">
        <h2>الأمان والحماية</h2>
        <?php
          if (isset($_POST['security'])) {
            $id = $user['id'];
            $password = trim($_POST['password']);
            $newPassword = trim($_POST['newpassword']);
            $confirmPassword = trim($_POST['confirmpassword']);
            $error = false;
              
            if ($password == "") {
              echo '<p class="error">يجب ان لا تترك خانة كلمة المرور الحالية فارغة</p>';
              $error = true;
            }
            
            if ($newPassword == "") {
              echo '<p class="error">يجب ان لا تترك خانة كلمة المرور الجديدة فارغة</p>';
              $error = true;
            }
            
            if ($confirmPassword == "") {
              echo '<p class="error">يجب ان لا تترك خانة تأكيد كلمة المرور الجديدة فارغة</p>';
              $error = true;
            }
            
            if ($newPassword != $confirmPassword) {
              echo '<p class="error">لا تتطابق كلمة المرور الجديدة مع التاكيد</p>';
              $error = true;
            }
            
            if (strlen($newPassword) < 8) {
              echo '<p class="error">يجب ان تحتوي كلمة المرور على 8 أحرف على الأقل</p>';
              $error = true;
            }
            
            $con = mysqli_connect('localhost', 'root', '', 'rabt');
            mysqli_set_charset($con, 'utf8');
            
            $checkPassword = mysqli_query($con, "select id from users where password = md5('$password') and id = '$id'");
            if (mysqli_num_rows($checkPassword) <= 0) {
              echo '<p class="error">تحقق من كلمة المرور الحالية</p>';
              $error = true;
            }
            
            if (!$error) {
              $update = mysqli_query($con, "update users set password = md5('$newPassword') where id = '$id'");
              if ($update) {
                echo "<p class='success'>تم تغيير كلمة المرور بنجاح</p>";
              }
            }
            
            mysqli_close($con);
          }
        ?>
        <form action="profile.php" method="post" onsubmit="checkSecurity(event)">
          <label>كلمة المرور الحالية</label>
          <input
            type="password"
            name="password"
            id="password"
            placeholder="ادخل كلمة المرور الحالية"
            class="input"
          />
          <label>كلمة المرور الجديدة</label>
          <input
            type="password"
            name="newpassword"
            id="newpassword"
            placeholder="ادخل كلمة المرور الجديدة"
            class="input"
          />
          <label>أكد كلمة المرور الجديدة</label>
          <input
            type="password"
            name="confirmpassword"
            id="confirmpassword"
            placeholder="ادخل كلمة المرور الجديدة مرة آخرى"
            class="input"
          />
          <input type="submit" name="security" class="btn" value="تغيير كلمة المرور" />
        </form>
      </div>
      <div class="group">
        <h2>التحكم في الحساب</h2>
        <?php
          // جزئية حسام
          if (isset($_GET['newsletter']) && $_GET['newsletter'] == 'false') {
            $con = mysqli_connect('localhost', 'root', '', 'rabt');
            mysqli_set_charset($con, 'utf8');
            $id = $user['id'];
            $email = $user['email'];
            
            //$delete = "DELETE FROM newsletter WHERE email = '$email'";
            $delete = "UPDATE users SET newsletter = '0' WHERE id = '$id'";
            $result = mysqli_query($con,$delete);
            
            if ($result) {
              echo "<p class='success'>تم الغاء إشتراك النشرة</p>";
              header("location: profile.php");
              exit;
            }
            
            mysqli_close($con);
          }
          // نهاية جزئية حسام
        
          if ($user['newsletter']) {
            echo '<a href="profile.php?newsletter=false" class="btn">الغاء إشتراك النشرة</a>';
          }
          
          
           if (isset($_GET['subscribtion']) && $_GET['subscribtion'] == 'false') {
            $con = mysqli_connect('localhost', 'root', '', 'rabt');
            mysqli_set_charset($con, 'utf8');
            
            $id = $user['id'];
            $updateUser = mysqli_query($con, "update users set subscribed = '0' where id = '$id'");
            $updatePayment = mysqli_query($con, "update payments set status = 'cancelled' where user = '$id' and status = 'success'");
            
            $user['subscribed'] = 0;
            $_COOKIE['user'] = json_encode($user);
            setcookie("user", json_encode($user), time() + 60 * 60 * 24 * 7, '/');
            
            if ($updateUser && $updatePayment) {
              echo "<p class='success'>تم الغاء إشتراك الباقة</p>";
              header("location: pricing.php");
              exit;
            }
            mysqli_close($con);
          }
          
          if ($user['subscribed'] == 1) {
            echo '<a href="profile.php?subscribtion=false" class="btn green">الغاء إشتراك الباقة</a>';
          }
          
          // جزئية تركي
          if (isset($_GET['delete']) && $_GET['delete'] == 'true') {
            $con = mysqli_connect('localhost', 'root', '', 'rabt');
            mysqli_set_charset($con, 'utf8');
            
            $id = $user['id'];
            $delete = "delete from users where id = '$id'";
            $delete = mysqli_query($con, $delete);
            
            if ($delete) {
              header("location: logout.php");
              exit;
            }
            
            mysqli_close($con);
          }
          // نهاية جزئية تركي
        ?>
        <a href="profile.php?delete=true" class="btn red" onclick="confirmDelete(event)">حذف الحساب</a>
      </div>
    <?php
      include './assets/php/sidebar_footer.php';
    ?>
    <script src="./assets/js/profile.js"></script>
  </body>
</html>

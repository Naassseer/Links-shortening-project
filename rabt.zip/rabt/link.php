<?php
     $con = mysqli_connect('localhost', 'root', '', 'rabt');
     mysqli_set_charset($con, 'utf8');

    if(isset($_GET['link']) && !empty($_GET['link'])){
        $id = $_GET['link'];
        $check = "select link from links where id = '$id' and status = '1'";
        $check = mysqli_query($con, $check);
        if(mysqli_num_rows($check) > 0){
            $link = mysqli_fetch_array($check)['link'];
            $update_visit = "update links set visits = visits + '1' where id = '$id'";
            mysqli_query($con, $update_visit);
            header('location: ' . $link);
            exit();
        }else{
            echo('لم يتم العثور على الرابط');
        }
    }else{
        echo('لم يتم العثور على الرابط');
    }

     mysqli_close($con);
?>
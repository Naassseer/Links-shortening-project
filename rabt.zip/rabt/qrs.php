<!DOCTYPE html>
<html>

<head>
	<title>ربط - رموز QR</title>
	<link rel="icon" type="image/png" href="./assets/img/favicon.png" />
	<link rel="stylesheet" href="./assets/css/style.css" />
	<link rel="stylesheet" href="./assets/css/sidebar.css" />
	<link rel="stylesheet" href="./assets/css/qrs_links.css" />
</head>

<body class="dashboard">
	<?php
		include './assets/php/auth.php';
		if (!$loggedIn) {
			header("location: login.php");
			exit;
		}
		
		$page = 'qrs';
		include './assets/php/sidebar_header.php';
	?>
		<div class="q-l-heading">
			<h1>
				رموز ال QR <button class="lk-btn" onclick="showDialog()">+ رمز QR جديد</button>
			</h1>
		</div>
		<?php
			$con = mysqli_connect('localhost', 'root', '', 'rabt');
			mysqli_set_charset($con, 'utf8');
			
			if(isset($_GET['id']) && isset($_GET['update'])) {
				$id = trim($_GET['id']);
				$check_id = "select status from qrs where id = '$id'";
				$check_id = mysqli_query($con,  $check_id);
				if(mysqli_num_rows($check_id)> 0){
					if($_GET['update'] == 'status'){
						$status = mysqli_fetch_array($check_id)['status'];
						$new_status = $status == 1 ? 0 : 1;
						$update_status = "update qrs set status = '$new_status' where id = '$id'";
						$run_update = mysqli_query($con, $update_status );
						echo "<script>window.location='qrs.php'</script>";
						exit;
					}else if($_GET['update'] == 'delete'){
						$delete_link = "delete from qrs where id = '$id'";
						$run_delete = mysqli_query($con, $delete_link);
						echo "<script>window.location='qrs.php'</script>";
						exit;
					}
				}
			}
			
			$qrs = "select * from qrs where user = '1'";
			$qrs = mysqli_query($con, $qrs);
			
			if (mysqli_num_rows($qrs) <= 0) {
				echo ('<p class="error">لا توجد رموز QR </p>');	
			} else {
				while($qr = mysqli_fetch_array($qrs)) {
					$status = $qr['status'] == '1' ? 'on' : 'off';
					$status_str = $qr['status'] == '1' ? 'نشط' : 'غير نشط';
					$date = date_create($qr['created_at']);
					$date = date_format($date,"M d, Y"); 
					$url = "http://localhost/rabt2/qr.php?link=" . $qr['id'];
					$api = "https://chart.googleapis.com/chart?cht=qr&chl=" . $url . "&choe=UTF-8&chs=500x500"
			
		?>
		
			<div class="qr-info">
				<div class="text" style="display: inline-block">
					<h3 class="q-l-title"><?php echo $qr['name'] ?></h3>
					<a class="q-l-link" href="<?php echo $qr['link'] ?>"><?php echo $qr['link'] ?></a>
					<h5 class="q-l-explanation"><?php echo $qr['scans'] ?> <bdi>مرات المسح</bdi> <?php echo $date; ?></h5>
				</div>
				<div class="info_qr">
					<a href="qrs.php?id=<?php echo $qr['id'] ?>&update=status" class="btn <?php echo $status ?> ">
						<span class="ico-<?php echo $status ?>"></span>
						<?php echo $status_str ?>
					</a>
					<a href="<?php echo $api ?>" target="_blank" class="btn download">
						<span class="ico-download"></span>
						تحميل
					</a>
					<a href="qrs.php?id=<?php echo $qr['id'] ?>&update=delete" class="btn delete">
						<span class="ico-delete"></span>
					</a>
				</div>
			</div>
		
		<?php
				}
			}
		?>
	</div>
	<?php
	include('./assets/php/dialog_qrs.php');
	mysqli_close($con);
	?>
	<script src="./assets/js/links_qrs.js"></script>
</body>

</html>
<!DOCTYPE html>
<html>
  <head>
    <title>ربط - لوحة التحكم</title>
    <link rel="icon" type="image/png" href="./assets/img/favicon.png" />
    <link rel="stylesheet" href="./assets/css/style.css" />
    <link rel="stylesheet" href="./assets/css/sidebar.css" />
    <link rel="stylesheet" href="./assets/css/dashboard.css" />
  </head>
  <body class="husam dashboard">
    <?php
      include './assets/php/auth.php';
      if (!$loggedIn) {
        header("location: login.php");
        exit;
      }
    
      $page = 'dashboard';
      include './assets/php/sidebar_header.php';
      
      $con = mysqli_connect('localhost', 'root', '', 'rabt');
      mysqli_set_charset($con, "utf8");
      
      $userid = $user['id'];
      $getLinks = mysqli_query($con, "SELECT name, visits FROM links WHERE user = '$userid' ORDER BY visits DESC");
      $links = [];
      $links_count = 0;
      if (mysqli_num_rows($getLinks) >= 1) {
        $links = mysqli_fetch_all($getLinks, MYSQLI_ASSOC);
        $links_count = mysqli_num_rows($getLinks);
      }
      
      $getQRS = mysqli_query($con, "SELECT name, scans FROM qrs WHERE user = '$userid' ORDER BY scans DESC");
      $qrs = [];
      $qrs_count = 0;
      if (mysqli_num_rows($getQRS) >= 1) {
        $qrs = mysqli_fetch_all($getQRS, MYSQLI_ASSOC);
        $qrs_count = mysqli_num_rows($getQRS);
      }
      
      $plan_links = $user['subscribed'] == 1 ? 100 : 20;
      $used_links = min(($links_count / $plan_links) * 100, 100);
      
      $plan_qrs = $user['subscribed'] == 1 ? 20 : 2;
      $used_qrs = min(($qrs_count /  $plan_qrs) * 100, 100);
      
    ?>
      <h2>لوحة التحكم</h2>
      <div class="row r1">
        <div class="card shortcuts">
          <h4>اختصارات</h4>
          <a href="links.php#dialog" class="btn pd-y-sm f-width"
            >انشئ رابط جديد</a
          >
          <a href="qrs.php#dialog" class="btn pd-y-sm f-width"
            >انشئ رمز QR جديد</a
          >
          <a href="profile.php" class="btn pd-y-sm f-width">حسابي</a>
        </div>
        <div class="card usage">
          <h4>الاستخدام</h4>
          <div class="usage-group">
            <div class="text">
              <h5>الروابط المختصرة</h5>
              <p><?php echo $links_count . " من " . $plan_links . ' استخدام' ?></p>
            </div>
            <div class="progress">
              <div class="used" style="width: <?php echo $used_links ?>%"></div>
            </div>
          </div>
          <div class="usage-group">
            <div class="text">
              <h5>رموز الQR</h5>
              <p><?php echo $qrs_count . " من " . $plan_qrs . ' استخدام' ?></p>
            </div>
            <div class="progress">
              <div class="used" style="width: <?php echo $used_qrs ?>%"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="row r2">
        <div class="card">
          <h4>زيارات الروابط</h4>
          <div>
            <canvas id="visitsChart" style="width: 100%; height: 100%"></canvas>
          </div>
        </div>
        <div class="card">
          <h4>مرات مسح رموز الQR</h4>
          <div>
            <canvas id="scansChart" style="width: 100%; height: 100%"></canvas>
          </div>
        </div>
      </div>
      <?php
        if ($user['subscribed'] == 0) {
      ?>  
          <div class="row r3">
            <div class="card">
              <h2>استفد إلى أقصى حد</h2>
              <p>
                دعنا نساعدك في تحقيق أهدافك الرقمية بسهولة وفعالية. انضم اليوم وشهد
                الفارق.
              </p>
              <a href="pricing.php" class="btn pd-y-sm pd-x-bg has-ico">
                قم بالترقية الآن
                <span class="ico-goto"></span>
              </a>
            </div>
          </div>
      <?php
        }
      ?>
    </div>
    <?php
      include './assets/php/sidebar_footer.php';
    ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
      Chart.defaults.borderColor = '#1e1e1e';
      Chart.defaults.color = '#777';

      var visitsChart = document.getElementById('visitsChart');
      var scansChart = document.getElementById('scansChart');

      var labels = [
        <?php
          if ($links_count >= 1) {
            for ($i = 0; $i < min($links_count, 5); $i++) {
              $link = $links[$i];
              echo '"' . $link['name'] . '",'; 
            }
          }
        ?>
      ];

      new Chart(visitsChart, {
        type: 'bar',
        data: {
          labels,
          datasets: [
            {
              label: 'عدد الزيارات',
              data: [
                <?php
                  if ($links_count >= 1) {
                    for ($i = 0; $i < min($links_count, 5); $i++) {
                      $link = $links[$i];
                      echo $link['visits'] . ','; 
                    }
                  }
                ?>
              ],
              backgroundColor: '#232E46',
            },
          ],
        },
        options: {
          plugins: {
            legend: {
              display: false,
            },
          },
          scales: {
            y: {
              ticks: {
                precision: 0
              }
            }
          }
        },
      });
      
      labels = [
        <?php
          if ($qrs_count >= 1) {
            for ($i = 0; $i < min($qrs_count, 5); $i++) {
              $qr = $qrs[$i];
              echo '"' . $qr['name'] . '",'; 
            }
          }
        ?>
      ];  
      
      new Chart(scansChart, {
        type: 'bar',
        data: {
          labels,
          datasets: [
            {
              label: 'عدد مرات المسح',
              data: [
                <?php
                  if ($qrs_count >= 1) {
                    for ($i = 0; $i < min($qrs_count, 5); $i++) {
                      $qr = $qrs[$i];
                      echo $qr['scans'] . ','; 
                    }
                  }
                ?>
              ],
              backgroundColor: '#232E46',
            },
          ],
        },
        options: {
          plugins: {
            legend: {
              display: false,
            },
          },
          scales: {
            y: {
              ticks: {
                precision: 0
              }
            }
          }
        },
      });
    </script>
  </body>
</html>

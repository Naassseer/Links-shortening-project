<?php
  include './assets/php/auth.php';
?>

<!DOCTYPE html>
<html>
  <head>
    <title>ربط - الباقات</title>
    <link rel="icon" type="image/x-icon" href="./assets/img/favicon.ico" />
    <link rel="stylesheet" href="./assets/css/style.css" />
    <link rel="stylesheet" href="./assets/css/sidebar.css" />
    <link rel="stylesheet" href="./assets/css/pricing.css" />
  </head>
  <body class="<?php echo $loggedIn ? 'dashboard' : 'husam' ?>">
      <?php        
        if ($loggedIn) {
          $page = "pricing";
          
          include './assets/php/sidebar_header.php';
          echo '<h1>الباقات</h1>';
          
          if (isset($_GET['upgrade'])) {
            echo "<p class='success'>تم الإشتراك في الباقة الإحترافية</p>";
          }
        } else {
          include './assets/php/main_header.php';
        }
      ?>
      
      <div class="section pricing">
        <div class="plan">
          <h2>$0</h2>
          <h3>الباقة المجانية</h3>
          <ul>
            <li>— 20 رابط مختصر</li>
            <li>— 2 رمز QR</li>
            <li>— تتبع إحصائيات الروابط والرموز</li>
          </ul>
          
          <?php
            if ($loggedIn) {
              if ($user['subscribed'] == 1) {
                $link = "profile.php?subscribtion=false";
                $text = "اختيار الخطة <span class='ico-goto'></span>";
              } else {
                $link = "#";
                $text = "الخطة الحالية";
              }
            }else{
              $link = "signup.php";
              $text = "جرب الأن <span class='ico-goto'></span>";
            }
          ?>
          <a href="<?php echo $link ?>">
            <?php echo $text ?>
          </a>
        </div>
        <div class="plan pro">
          <h2>$9</h2>
          <h3>الباقة الإحترافية</h3>
          <ul>
            <li>— 100 رابط مختصر</li>
            <li>— 20 رمز QR</li>
            <li>— تتبع إحصائيات الروابط والرموز</li>
          </ul>
          
          <?php
            if ($loggedIn) {
              if ($user['subscribed'] == 0) {
                $link = "payment.php";
                $text = "اختيار الخطة <span class='ico-goto'></span>";
              } else {
                $link = "#";
                $text = "الخطة الحالية";
              }
            }else{
              $link = "signup.php";
              $text = "جرب الأن <span class='ico-goto'></span>";
            }
          ?>
          <a href="<?php echo $link ?>">
            <?php echo $text ?>
          </a>
        </div>
      </div>
    <?php
      if ($loggedIn) {
        include './assets/php/sidebar_footer.php';
      } else {
        echo '</main>';
        include './assets/php/main_footer.php';
      }
    ?>
  </body>
</html>

<!DOCTYPE html>
<html>

<head>
  <title>ربط - الروابط المختصرة</title>
  <link rel="icon" type="image/png" href="./assets/img/favicon.png" />
  <link rel="stylesheet" href="./assets/css/style.css" />
  <link rel="stylesheet" href="./assets/css/sidebar.css" />
  <link rel="stylesheet" href="./assets/css/qrs_links.css" />
</head>

<body class="dashboard">
  <?php
    include './assets/php/auth.php';
    if (!$loggedIn) {
      header("location: login.php");
      exit;
    }
    
    $page = "links";
    include './assets/php/sidebar_header.php';
  ?>
    <div class="q-l-heading">
      <h1>
        الروابط المختصرة <button class="lk-btn" onclick="showDialog()">+ رابط جديد</button>
      </h1>
    </div>
    <?php
    $con = mysqli_connect('localhost', 'root', '', 'rabt');
    mysqli_set_charset($con, 'utf8');
    
    if(isset($_GET['id']) && isset($_GET['update'])){
      $id = trim($_GET['id']);
      $userid = $user['id'];
      $check_id = "select status from links where id = '$id' and user = '$userid'";
      $check_id = mysqli_query($con,  $check_id);
      if(mysqli_num_rows($check_id)> 0){
        if($_GET['update'] == 'status'){
          $status = mysqli_fetch_array($check_id)['status'];
          $userid = $user['id'];
          $new_status = $status == 1 ? 0 : 1;
          $update_status = "update links set status = '$new_status' where id = '$id'";
          $run_update = mysqli_query($con, $update_status );
          echo "<script>window.location='links.php'</script>";

        }else if($_GET['update'] == 'delete'){
          $delete_link = "delete from links where id = '$id'";
          $run_delete = mysqli_query($con, $delete_link);
          echo "<script>window.location='links.php'</script>";
        }
      }
    }
    
    

    $userid = $user['id'];
    $getlinks = "select * from links where user = '$userid' order by id desc";
    $links = mysqli_query($con, $getlinks);
    if (mysqli_num_rows($links) <= 0) {
      echo ('<p class="error">لا يوجد روابط </p>');
    } else {
      while($link = mysqli_fetch_array($links)) {
        $status = $link['status'] == '1' ? 'on' : 'off';
        $status_str = $link['status'] == '1' ? 'نشط' : 'غير نشط';
        $date = date_create($link['created_at']);
        $date = date_format($date,"M d, Y"); 
    ?>
        <div class="lk-info">
          <div class="text" style="display: inline-block">
            <h3 class="q-l-title"><?php echo $link['name'] ?></h3>
            <a class="lk-link" href="http://localhost/rabt/link.php?link=<?php echo $link['id'] ?>">http://localhost/rabt/link.php?link=<?php echo $link['id'] ?></a>
            <a class="q-l-link" href="<?php echo $link['link'] ?>"><?php echo $link['link'] ?></a>
            <h5 class="q-l-explanation"><?php echo $link['visits'] ?> <bdi>مشاهدة</bdi> <?php echo $date; ?></h5>
          </div>
          <div class="info_lk">
            <a href="links.php?id=<?php echo $link['id'] ?>&update=status" class="btn <?php echo $status ?> ">
              <span class="ico-<?php echo $status ?>"></span>
              <?php echo $status_str ?>
            </a>
            <a href="#" class="btn copy" onclick="copy('http://localhost/rabt/link.php?link=<?php echo $link['id'] ?>')">
              <span class="ico-copy"></span>
              نسخ
            </a>
            <a href="links.php?id=<?php echo $link['id'] ?>&update=delete" class="btn delete">
              <span class="ico-delete"></span>
            </a>
          </div>
        </div>
    <?php
      }
    }
    ?>
  </div>
  <?php
  include('./assets/php/dialog_links.php');
  include './assets/php/sidebar_footer.php';
  
  mysqli_close($con);
  ?>
  <script src="./assets/js/links_qrs.js"></script>
</body>

</html>
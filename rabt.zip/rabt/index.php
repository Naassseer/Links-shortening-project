<!DOCTYPE html>
<html>
  <head>
    <title>ربط - الرئيسية</title>
    <link rel="icon" type="image/x-icon" href="./assets/img/favicon.ico" />
    <link rel="stylesheet" href="./assets/css/style.css" />
  </head>
  <body class="husam">
    <?php
      include './assets/php/auth.php';
      
      if ($loggedIn) {
        header("location: dashboard.php");
        exit();
      }
    
      include './assets/php/main_header.php';
    ?>
      <div class="section hero">
        <h1><span>أسرع وأسهل</span> طريقة لاختصار الروابط ومشاركتها</h1>
        <p>
          حول روابطك الطويلة إلى روابط مختصرة بسهولة وسرعة، وتتبع الإحصائيات حول
          أدائها
        </p>
        <div class="actions">
          <a href="signup.php" class="btn pd-y-sm pd-x-bg m-left has-ico"
            >جرب الأن
            <span class="ico-goto"></span>
          </a>
          <a href="#why" class="btn border pd-y-sm">اعرف المزيد</a>
        </div>
      </div>
      <img
        src="./assets/img/hero.svg"
        alt="شعار ربط كبير - الرئيسية"
        class="bg-img"
      />
    </main>
    <div class="why">
      <div id="why" class="section">
        <h3>لماذا ربط</h3>
        <p>نساهم في جعل تجربة اختصار الروابط أكثر راحة وفعالية</p>
        <div class="reasons">
          <div class="reason">
            <span>01</span>
            <h4>سهولة الاستخدام</h4>
            <p>واجهة بسيطة وسهلة الاستخدام لاختصار الروابط بضغطة زر</p>
          </div>
          <div class="reason">
            <span>02</span>
            <h4>سرعة التصفح</h4>
            <p>
              روابطنا المختصرة تحمل بسرعة، مما يوفر وقتًا قيمًا لمشاركتها بسهولة
            </p>
          </div>
          <div class="reason">
            <span>03</span>
            <h4>إحصائيات متقدمة</h4>
            <p>نتيح لك الوصول إلى إحصائيات مفصلة حول أداء روابطك المختصرة.</p>
          </div>
          <div class="reason">
            <span>04</span>
            <h4>أمان وخصوصية</h4>
            <p>نحرص على أمان بياناتك وخصوصيتك اثناء استخدامك</p>
          </div>
        </div>
        <a href="signup.php" class="btn border bottom has-ico"
          >اكتشف الفرق
          <span class="ico-goto"></span>
        </a>
      </div>
    </div>
    <?php
      include './assets/php/main_footer.php';
    ?>
  </body>
</html>

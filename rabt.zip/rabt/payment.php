<?php
    include './assets/php/auth.php';
    
    if (!$loggedIn) {
        header("location: login.php");
    }
    
    if ($user['subscribed'] == 1) {
        header("location: profile.php");   
    }
    
    $con = mysqli_connect('localhost', 'root', '', 'rabt');
    mysqli_set_charset($con, 'utf8');
    
    $userid = $user['id'];
        
    $insert = mysqli_query($con, "insert into payments (user, amount) values('$userid', '9')");
    
    $update = mysqli_query($con, "update users set subscribed = '1' where id = '$userid'");
    
    $user['subscribed'] = 1;
    $_COOKIE['user'] = json_encode($user);
    setcookie("user", json_encode($user), time() + 60 * 60 * 24 * 7, '/');
    
    mysqli_close($con);
    header("location: pricing.php?upgrade");
    exit;
    
?>
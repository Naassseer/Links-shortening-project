<div class="sidebar-container">
    <div class="sidebar">
    <div class="main">
        <img class="logo" src="./assets/img/logo.svg" alt="شعار ربط" />
        <div class="menu">
        <a href="dashboard.php" class="<?php echo $page == "dashboard" ? 'active' : '' ?> unique">
            <span class="ico-home"></span>
            الرئيسية
        </a>
        <a href="links.php" class="<?php echo $page == "links" ? 'active' : '' ?>">
            <span class="ico-link"></span>
            الروابط المختصرة
        </a>
        <a href="qrs.php" class="<?php echo $page == "qrs" ? 'active' : '' ?>">
            <span class="ico-qr"></span>
            رموز الQR
        </a>
        </div>
    </div>
    <div class="menu">
        <?php
            if ($user['subscribed'] == 0) {
        ?>
            <a href="pricing.php" class="upgrade unique">
                <span class="ico-plan"></span>
                قم بترقية باقتك
            </a>
        <?php
            }
        ?>
        
        <a href="profile.php" class="<?php echo $page == "profile" ? 'active' : '' ?>">
        <span class="ico-profile"></span>
        حسابي
        </a>
        <a href="logout.php" class="logout unique">
        <span class="ico-logout"></span>
        تسجيل الخروج
        </a>
    </div>
    </div>
</div>
<div class="content">
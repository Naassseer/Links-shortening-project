<div class="dialog" id="dialog">
    <form action="#dialog" method="post" onsubmit="submitForm(event)">
        <?php
        if (isset($_POST['name'])) {
            $userid = $user['id'];
            $con = mysqli_connect('localhost', 'root', '', 'rabt');
            mysqli_set_charset($con, 'utf8');

            $name = trim($_POST['name']);
            $link = trim($_POST['link']);
            $error = false;

            if (empty($name) || empty($link)) {
                echo ('<p class="error">الرجاء تعبئة النموذج</p>');
                $error = true;
            }
            if (!filter_var($link, FILTER_VALIDATE_URL)) {
                echo ('<p class="error">الرجاء ادخال رابط صحيح</p>');
                $error = true;
            }

            if (!$error) {
                $check = "select * from qrs where (name = '$name' and user = '$userid') or (link = '$link' and user = '$userid')";
                $runCheck = mysqli_query($con, $check);
                if (mysqli_num_rows($runCheck) > 0) {
                    echo ('<p class="error">الاسم او الرابط مستخدمان من قبل</p>');
                } else {
                    $insert = "insert into qrs (user, name , link) values('$userid', '$name', '$link')";
                    $runInsert = mysqli_query($con, $insert);
                    echo ('<p class="success">تم انشاء رمز QR بنجاح</p>');
                }
            }
        }
        ?>
        <a href="#" onclick="hideDialog()"><span class="ico-off"></span></a>
        <h3 style="font-size: 18px; margin-bottom: 10px;">رمز QR جديد</h3>
        <label for="name" style="font-size: 15px;">اسم الرابط</label><br>
        <input class="fm_edit" type="text" name="name" id="name" size="25px" placeholder="ادخل اسم الرابط" /><br>
        <label for="name" style="font-size: 15px;">الرابط المراد تحويله</label><br>
        <input class="fm_edit" type="url" name="link" id="link" size="25px" placeholder="ادخل الرابط المراد تحويله" /><br>
        <input type="submit" value="انشئ QR" class="sm_edit" />
    </form>
</div>
<footer>
  <div class="section">
    <div class="bio">
      <div class="logo">
        <img
          src="./assets/img/logo-white.svg"
          alt="شعار ربط - الرئيسية"
          class="logo"
        />
        <h2>ربط</h2>
      </div>
      <p>
        حول روابطك الطويلة إلى روابط مختصرة بسهولة وسرعة، وتتبع الإحصائيات
        حول أدائها
      </p>
    </div>
    <div class="links">
      <h4>روابط الموقع</h4>
      <ul>
        <li><a href="index.php">الرئيسية</a></li>
        <li><a href="pricing.php">الباقات</a></li>
        <li><a href="login.php">لوحة التحكم</a></li>
      </ul>
    </div>

    <div class="newsletter">
      <h4>اشترك في النشرة</h4>
      <p>اشترك في نشرتنا ليصلك كل جديد</p>
      
      <?php
        $msg = "";
        $class = "";
        $btn = '
          اشترك
          <span class="ico-goto"></span>
        ';
      
        if (isset($_POST['email'])) {
          $con = mysqli_connect('localhost', 'root', '', 'rabt');
          mysqli_set_charset($con, "utf8");
          
          $email = $_POST['email'];
          
          if ($email != "" || filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $query = "SELECT email FROM newsletter WHERE email = '$email'";
            $result = mysqli_query($con, $query);
            
            if (mysqli_num_rows($result) <= 0) {
              $insert = "INSERT INTO newsletter(email) VALUES ('$email')";
              $result = mysqli_query($con, $insert);
              $msg = "تم تسجيلك في النشرة بنجاح";
              $class = "success";
              $btn = '
                <span class="ico-on"></span>
              ';
            } else {
              $msg = "انت مسجل في النشرة من قبل";
              $class = "error";
            } 
          } else {
              $msg = "تأكد من البريد الإلكتروني";
              $class = "error";
          }
          
          mysqli_close($con);
        }
      ?>
      <form id="newsletter" class="<?php echo $class ?>" action="index.php#newsletter" method="post">
        <input
          type="email"
          name="email"
          placeholder="ادخل بريدك الإلكتروني"
        />
        <button type="submit" class="btn black pd-y-sm has-ico">
          <?php echo $btn ?>
        </button>
        <p class="msg"><?php echo $msg ?></p>
      </form>
    </div>
  </div>
</footer>
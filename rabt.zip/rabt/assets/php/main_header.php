<main>
      <div class="section navbar">
        <nav>
          <a href="index.php"
            ><img
              src="./assets/img/logo.svg"
              alt="شعار ربط - الرئيسية"
              class="logo"
          /></a>
          <a href="#why">لماذا نحن</a>
          <a href="pricing.php">الباقات</a>
        </nav>
        <div class="account">
          <a href="login.php" class="btn transparent pd-x-sm m-left"
            >تسجيل الدخول</a
          >
          <a href="signup.php" class="btn">انشئ حسابك — مجاناً</a>
        </div>
      </div>
function checkPreference(event, username, email) {
  var newUsername = document.getElementById('username').value;
  var newEmail = document.getElementById('email').value;
  var error = false;

  if (username == newUsername && email == newEmail) {
    error = true;
    alert('لم تعدل على اسم المستخدم والبريد الإلكتروني');
  }

  if (newUsername == '') {
    error = true;
    alert('يجب ان لا تترك خانة اسم المستخدم فارغة');
  }

  if (newEmail == '') {
    error = true;
    alert('يجب ان لا تترك خانة البريد الإلكتروني فارغة');
  }

  if (newUsername.includes(' ')) {
    error = true;
    alert('يجب ان لا يحتوي اسم المستخدم على مسافات');
  }

  if (!newEmail.includes('@') || !newEmail.includes('.')) {
    error = true;
    alert('يجب ان يكون البريد الإلكتروني المدخل صحيح');
  }

  if (error) {
    event.preventDefault();
  }
}

function checkSecurity(event) {
  var password = document.getElementById('password').value;
  var newPassword = document.getElementById('newpassword').value;
  var confirmPassword = document.getElementById('confirmpassword').value;
  var error = false;

  if (password == '') {
    alert('يجب ان لا تترك خانة كلمة المرور الحالية فارغة');
    error = true;
  }

  if (newPassword == '') {
    alert('يجب ان لا تترك خانة كلمة المرور الجديدة فارغة');
    error = true;
  }

  if (confirmPassword == '') {
    alert('يجب ان لا تترك خانة تأكيد كلمة المرور الجديدة فارغة');
    error = true;
  }

  if (newPassword != confirmPassword) {
    alert('لا تتطابق كلمة المرور الجديدة مع التاكيد');
    error = true;
  }

  if (newPassword.length < 8) {
    alert('يجب ان تحتوي كلمة المرور على 8 أحرف على الأقل');
    error = true;
  }

  if (error) {
    event.preventDefault();
  }
}

function confirmDelete(event) {
  var deleteUser = confirm('هل تريد تأكيد حذف الحساب؟');

  if (!deleteUser) {
    event.preventDefault();
  }
}

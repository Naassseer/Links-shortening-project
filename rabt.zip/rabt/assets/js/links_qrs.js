function showDialog() {
  var dialog = document.getElementById('dialog');
  dialog.classList.add('show');
}

function hideDialog() {
  var dialog = document.getElementById('dialog');
  dialog.classList.remove('show');
}
function dialogFocus() {
  var url = window.location.href.split('#');
  if (url.length > 1 && url[1] == 'dialog') {
    showDialog();
  }
}
window.addEventListener('load', function () {
  dialogFocus();
});

function copy(link) {
  navigator.clipboard.writeText(link);
  alert('تم نسخ الرابط ');
}

function downloadQR(name, url) {
  var link = document.createElement('a');
  link.download = name;
  link.href =
    'https://chart.googleapis.com/chart?cht=qr&chl=' +
    url +
    '&choe=UTF-8&chs=500x500';
  link.click();
}
